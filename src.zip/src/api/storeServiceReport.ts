type RNFile = {
  uri: string;
  name: string;
  type: string;
};
export type ServiceReportMode = "submit" | "draft";

export interface ServiceReportStoreParams {
  token: string;
  report_id: number;
  user_id: number;
  company_name: string;
  company_address: string;
  job_no: string;
  hr_meter: string;
  equipment_type: string;
  equipment_id: string;
  serial_no: string;
  mc: string;
  date_list: string[]; // date1..4
  time_list: {
    start: string[]; // start_time1..4
    end: string[];   // end_time1..4
  };
  operation_check_list: {
    general_list: Record<string, boolean>;
    forklift_list: Record<string, boolean>;
    aerial_platform_list: Record<string, boolean>;
  };
  servicing_parts_lubricants_list: Record<string, string>;
  other_parts_supplied_list: string[];
  description_status_list: {
    checking: boolean;
    servicing: boolean;
    repair: boolean;
  };
  description: string;
  signature_technician?: RNFile;
  signature_client?: RNFile;
  filled_date: string;
  is_chargable: string;
  client_name: string;
  client_tel_no: string;
  images: RNFile[];
}
export const storeServiceReportApi = async (params: ServiceReportStoreParams,
  mode: ServiceReportMode) => {
  const BASE_URL = process.env.EXPO_PUBLIC_BASE_URL!;

  try {
  
    const formData = new FormData();

    formData.append("user_id", String(params.user_id));
    formData.append("company_name", params.company_name);
    formData.append("company_address", params.company_address);
    formData.append("job_no", params.job_no);
    formData.append("hr_meter", params.hr_meter);
    formData.append("equipment_type", params.equipment_type);
    formData.append("equipment_id", params.equipment_id);
    formData.append("serial_no", params.serial_no);
    formData.append("mc", params.mc);

    // Dates
    params.date_list.forEach((d, i) => formData.append(`date_list[date${i + 1}]`, d));
    // Times
    params.time_list.start.forEach((t, i) => formData.append(`time_list[start_time${i + 1}]`, t));
    params.time_list.end.forEach((t, i) => formData.append(`time_list[end_time${i + 1}]`, t));

    // Operation checklist
    Object.entries(params.operation_check_list).forEach(([group, items]: any) => {
      Object.entries(items).forEach(([key, value]) => {
        formData.append(`operation_check_list[${group}][${key}]`, String(value));
      });
    });

    // Parts & lubricants
    Object.entries(params.servicing_parts_lubricants_list).forEach(([key, val]) => {
      formData.append(`servicing_parts_lubricants_list[${key}]`, val);
    });
    params.other_parts_supplied_list.forEach(val => formData.append("other_parts_supplied_list[]", val));

    // Description status
    formData.append("description_status_list[checking]", String(params.description_status_list.checking));
    formData.append("description_status_list[servicing]", String(params.description_status_list.servicing));
    formData.append("description_status_list[repair]", String(params.description_status_list.repair));
    formData.append("description", params.description);

    // Images
    params.images.forEach((img, index) => {
      formData.append(
        "images[]",
        {
          uri: img.uri,
          name: img.name || `image_${index}.jpg`,
          type: img.type || "image/jpeg",
        } as any
      );
    });
    
    // Signatures
    if (params.signature_technician) {
      formData.append(
        "signature_technician",
        {
          uri: params.signature_technician,
          name: params.signature_technician.name ?? "technician_signature.png",
          type: params.signature_technician.type ?? "image/png",
        } as any
      );
    }
    if (params.signature_client) {
      formData.append(
        "signature_client",
        {
          uri: params.signature_client,
          name: params.signature_client.name ?? "client_signature.png",
          type: params.signature_client.type ?? "image/png",
        } as any
      );
    }    

    formData.append("filled_date", params.filled_date);
    formData.append("is_chargable", params.is_chargable);
    formData.append("client_name", params.client_name);
    formData.append("client_tel_no", params.client_tel_no);

    console.log("=== FORMDATA START ===");
    for (const pair of formData.entries()) {
      console.log(pair[0], pair[1]);
    }
    console.log("=== FORMDATA END ===");
    

    // Decide endpoint here
    const endpoint =
      mode === "draft"
        ? "/service-report/draft"
        : "/service-report/store";

    const response = await fetch(`${BASE_URL}${endpoint}`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${params.token}`,
        Accept: "application/json",
      },
      body: formData,
    });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`HTTP ${response.status}: ${text}`);
  }

  return await response.json();

  } catch (err) {
    console.error("Service report store ERROR:", err);
    throw err;
  }
};

